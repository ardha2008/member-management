<?php print_r($messages);?>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="files"/>
    <button name="upload">Upload</button>
</form>