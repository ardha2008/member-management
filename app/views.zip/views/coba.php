<form method="post">
    <input type="text" name="input" /><button name="submit">Submit</button>
</form>